<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Deadline</h1>
    <!-- Page Heading -->
    <div class="card">
        <div class="card-body">
            <div class="container-fluid">
                <!-- DataTales Example -->
                <div class="card shadow mb-2">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Alamat</th>
                                        <th>Jumlah</th>
                                        <th>Tanggal Meminjam</th>
                                        <th>Tanggal Pelunasan</th>
                                        <th>Jaminan</th>
                                        <th>Deadline</th>
                                        <th>Bunga</th>
                                        <th>Keterangan</th>
                                        <th>Edit</th>
                                        <th>Hapus</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php foreach ($tb_peminjaman->getResultArray() as $raw) : ?>
                                        <tr>
                                            <td scope="raw"><?= $i; ?></td>
                                            <td><?= $raw['nm_peminjam']; ?></td>
                                            <td><?= $raw['alamat']; ?></td>
                                            <td><?= $raw['jumlah']; ?></td>
                                            <td><?= $raw['tgl_pjm']; ?></td>
                                            <td><?= $raw['tgl_plns']; ?></td>
                                            <td><?= $raw['jaminan']; ?></td>
                                            <td><?= $raw['deadline']; ?></td>
                                            <td><?= $raw['bunga']; ?></td>
                                            <td><?= $raw['ket']; ?></td>
                                            <td>
                                                <button type="submit" class="btn btn-secondary">
                                                    <i class="fas fa-edit text-gray"></i>
                                                </button>
                                            </td>
                                            <td>
                                                <center>
                                                    <button type="submit" class="btn btn-danger">
                                                        <i class="fas fa-trash text-gray"></i>
                                                    </button>
                                                </center>
                                            </td>

                                        </tr>
                                        <?php $i++; ?>
                                    <?php endforeach; ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->