<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Data Pengguna</h1>
    <!-- Page Heading -->
    <div class="card shadow">
        <div class="card-body">

            <?php if (session()->getFlashdata('pesan')) { ?>
                <div class="alert alert-success" id="alert-success" role="alert">
                    <?php echo session()->getFlashdata('pesan') ?>
                </div>
            <?php } ?>

            <?php if (session()->getFlashdata('gagal')) { ?>
                <div class="alert alert-danger" id="alert-success" role="alert">
                    <?php echo session()->getFlashdata('gagal') ?>
                </div>
            <?php } ?>
            <!-- DataTales Example -->

            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100vw" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>NIK</th>
                            <th>No. Hp</th>
                            <th>Alamat</th>
                            <th>Username</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($pengguna->getResultArray() as $raw) {
                        ?>
                            <tr>
                                <td><div class="text-dark"><?= $no++ ?></div></td>
                                <td><div class="text-dark"><?= $raw['nama_pengguna'] ?></div></td>
                                <td><div class="text-dark"><?= $raw['no_ktp'] ?></div></td>
                                <td><div class="text-dark"><?= $raw['no_hp'] ?></div></td>
                                <td width="100px"><div class="text-dark"><?= $raw['alamat'] ?></div></td>
                                <td><div class="text-dark"><?= $raw['email'] ?></div></td>
                                <td width="150px"><div class="text-dark">
                                    <?php if ($raw['user'] == 'admin') { ?>
                                        <div class="text-center">
                                            <a href="<?= base_url('/tambah_pengguna/edit/' . $raw['id_user']) ?>" class="btn btn-xs btn-warning" style=" margin: 5px auto;"><i class=" fa fa-edit"></i></a>
                                        </div>
                                    <?php } else { ?>
                                        <a href="<?= base_url('/tambah_pengguna/edit/' . $raw['id_user']) ?>" class="btn btn-xs btn-warning" style=" margin: 5px auto;"><i class=" fa fa-edit"></i></a>
                                        <button class="btn btn-xs btn-primary mr-1" data-toggle="modal" data-target="#resetModal<?= $raw['id_user'] ?>" title="Reset Password" style=" margin: 5px auto;"><i class=" fa fa-key"></i></a>
                                            <button class="btn btn-xs btn-danger" data-toggle="modal" data-target="#deleteModal<?= $raw['id_user'] ?>" style=" margin: 5px auto;"><i class=" fa fa-trash"></i></a>
                                            <?php } ?>
                                </div>
								</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
    <!-- /.container-fluid -->

</div>

<!-- Logout Modal-->
<?php foreach ($pengguna->getResultArray() as $raw) { ?>
    <div class="modal fade" id="deleteModal<?= $raw['id_user'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Hapus Pengguna</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Tekan delete jika ingin menghapus <?= $raw['nama_pengguna'] ?></div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    <a class="btn btn-danger" href="<?php echo base_url('pengguna/delete/' . $raw['id_user']) ?>">Delete</a>
                </div>
            </div>
        </div>
    </div>
<?php } ?>


<?php foreach ($pengguna->getResultArray() as $raw) { ?>

    <!-- Reset Password Modal-->
    <div class="modal fade" id="resetModal<?= $raw['id_user'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Reset Password <b><?= $raw['nama_pengguna'] ?></b></h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo base_url('pengguna/reset/' . $raw['id_user']); ?>">
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label">Password</label>
                            <div class="col-sm-8">
                                <?php $isInvalidPassword = (session()->getFlashdata('errPass')) ? 'is-invalid' : ''  ?>
                                <input name="password" class="form-control <?= $isInvalidPassword ?>" type="password">
                                <?php
                                if (session()->getFlashdata('errPass')) {
                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                    ' . session()->getFlashdata('errPass') . '
                                     </div>';
                                }
                                ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label">Confirm Password</label>
                            <div class="col-sm-8">
                                <?php $isInvalidConfPassword = (session()->getFlashdata('errConfPass')) ? 'is-invalid' : ''  ?>
                                <input name="conf_password" class="form-control <?= $isInvalidConfPassword ?>" type="password">
                                <?php
                                if (session()->getFlashdata('errConfPass')) {
                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                    ' . session()->getFlashdata('errConfPass') . '
                                     </div>';
                                }
                                ?>
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Reset</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php } ?>

<?php if (session()->getFlashdata('gagal')) { ?>

<?php } ?>