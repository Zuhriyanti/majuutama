<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Maju Utama</title>
    <link href="<?= base_url(); ?>/template/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="<?= base_url(); ?>/template/css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body class="bg-gradient-light">

    <div class="container col-lg-6">

        <div class="row justify-content-center">

            <div class="col-md-10">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">

                        <div class="row">
                            <div class="col-lg-5 d-none d-lg-block bg-login-image"></div>

                            <div class="col-lg-12">
                                <div class="p-3">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Selamat Datang</h1>
                                    </div>

                                    <form class="user" action="<?= site_url('login/loginCheck') ?>" method="POST">

                                        <label>User/Email</label>
                                        <div class="form-group">
                                            <?php
                                            if (session()->getflashdata('errEmail')) {
                                                $isInvalidEmail = 'is-invalid';
                                            } else {
                                                $isInvalidEmail = '';
                                            }
                                            ?>
                                            <input value="<?php echo session()->getFlashdata('email') ?>" type="email" name="email" class="form-control form-control-user <?= $isInvalidEmail ?>" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Masukkan User/Email">
                                            <?php
                                            if (session()->getFlashdata('errEmail')) {
                                                echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                        ' . session()->getFlashdata('errEmail') . '
                                                      </div>';
                                            }
                                            ?>
                                        </div>
                                        <label>Password</label>
                                        <div class="form-group">
                                            <?php
                                            if (session()->getflashdata('errPassword')) {
                                                $isInvalidPassword = 'is-invalid';
                                            } else {
                                                $isInvalidPassword = '';
                                            }
                                            ?>
                                            <input type="password" class="form-control form-control-user <?= $isInvalidPassword ?>" name="password" id="exampleInputPassword" placeholder="Masukkan Kata Sandi">
                                            <?php
                                            if (session()->getFlashdata('errPassword')) {
                                                echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                        ' . session()->getFlashdata('errPassword') . '
                                                      </div>';
                                            }
                                            ?>
                                        </div>
                                        <div class="form-group">
                                            <div class="custom-control custom-checkbox small">
                                                <input type="checkbox" class="custom-control-input" id="customCheck">
                                                <label class="custom-control-label" for="customCheck">Simpan Kata Sandi</label>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <center><input type="submit" name="login" class="btn btn-primary" value="LOGIN" />
                                            </center>
                                        </div>


                                    </form>
                                    <hr>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <script src="<?= base_url(); ?>/template/vendor/jquery/jquery.min.js"></script>
    <script src="<?= base_url(); ?>/template/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url(); ?>/template/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="<?= base_url(); ?>/template/js/sb-admin-2.min.js"></script>

</body>

</html>