<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Tambah Data Pengguna</h1>
    <div class="card">
        <div class="card-body">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-9">
                        <div class="card o-hidden border-0 shadow-lg my-2">
                            <div class="card-body p-0">
                                <div class="row">
                                    <div class="col-lg-5 d-none d-lg-block bg-register-image"></div>
                                    <div class="col-md-12">
                                        <div class="p-5">
                                            <div class="text-dark">
                                                <div class="col-12">
                                                    <h4 class="text-center mt-3">Masukkan Data Pengguna</h4><br>
                                                    <form action="<?php echo base_url('tambah_pengguna/save_registration') ?>" method="POST">
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Nama Lengkap</label>
                                                            <?php $isInvalidNama = (session()->getFlashdata('errNama')) ? 'is-invalid' : ''  ?>
                                                            <div class="col-sm-8">
                                                                <input value="<?php echo session()->getFlashdata('nama_pengguna') ?>" class="form-control <?= $isInvalidNama ?>" name="nama_pengguna" type="text" placeholder="Masukkan Nama">
                                                                <?php
                                                                if (session()->getFlashdata('errNama')) {
                                                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                                            ' . session()->getFlashdata('errNama') . '
                                                                        </div>';
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Nomor Induk Kependudukan (NIK)</label>
                                                            <div class="col-sm-8">
                                                                <?php $isInvalidNIK = (session()->getFlashdata('errNIK')) ? 'is-invalid' : ''  ?>
                                                                <input value="<?php echo session()->getFlashdata('no_ktp') ?>" class="form-control <?= $isInvalidNIK ?>" maxLength="16" name="no_ktp" type="text" placeholder="00xxxx">
                                                                <?php
                                                                if (session()->getFlashdata('errNIK')) {
                                                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                                            ' . session()->getFlashdata('errNIK') . '
                                                                        </div>';
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Tempat Tanggal Lahir</label>
                                                            <div class="col-sm-8">
                                                                <?php $isInvalidttl = (session()->getFlashdata('errTtl')) ? 'is-invalid' : ''  ?>
                                                                <input class="form-control <?= $isInvalidttl ?>" name="ttl" type="text" placeholder="Mataram, 17 Agustus 1945">
                                                                <?php
                                                                if (session()->getFlashdata('errTtl')) {
                                                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                                            ' . session()->getFlashdata('errTtl') . '
                                                                        </div>';
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Alamat Tinggal</label>
                                                            <?php $isInvalidAlamat = (session()->getFlashdata('errAlamat')) ? 'is-invalid' : ''  ?>
                                                            <div class="col-sm-8">
                                                                <input value="<?php echo session()->getFlashdata('alamat') ?>" class="form-control <?= $isInvalidAlamat ?>" name="alamat" type="text" placeholder="Masukkan Alamat">
                                                                <?php
                                                                if (session()->getFlashdata('errAlamat')) {
                                                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                                            ' . session()->getFlashdata('errAlamat') . '
                                                                        </div>';
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Nomor Hp</label>
                                                            <?php $isInvalidHp = (session()->getFlashdata('errHp')) ? 'is-invalid' : ''  ?>
                                                            <div class="col-sm-8">
                                                                <input value="<?php echo session()->getFlashdata('no_hp') ?>" class="form-control <?= $isInvalidHp ?>" maxLength="16" name="no_hp" type="text" placeholder="">
                                                                <?php
                                                                if (session()->getFlashdata('errHp')) {
                                                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                                            ' . session()->getFlashdata('errHp') . '
                                                                        </div>';
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Email</label>
                                                            <div class="col-sm-8">
                                                                <?php $isInvalidEmail = (session()->getFlashdata('errEmail')) ? 'is-invalid' : ''  ?>
                                                                <input value="<?php echo session()->getFlashdata('email') ?>" class="form-control <?= $isInvalidEmail ?>" name="email" type="email" placeholder="admin@gmail.com">
                                                                <?php
                                                                if (session()->getFlashdata('errEmail')) {
                                                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                                            ' . session()->getFlashdata('errEmail') . '
                                                                        </div>';
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Status</label>
                                                            <?php $isInvalidUser = (session()->getFlashdata('errUser')) ? 'is-invalid' : ''  ?>
                                                            <div class="col-sm-8">
                                                                <input class="form-control <?= $isInvalidUser ?>" name="user" type="text" placeholder="Admin/User">
                                                                <?php
                                                                if (session()->getFlashdata('errUser')) {
                                                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                                            ' . session()->getFlashdata('errUser') . '
                                                                        </div>';
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Password</label>
                                                            <div class="col-sm-8">
                                                                <?php $isInvalidPass = (session()->getFlashdata('errPass')) ? 'is-invalid' : ''  ?>
                                                                <input class="form-control <?= $isInvalidPass ?>" name="password" type="password" placeholder="">
                                                                <?php
                                                                if (session()->getFlashdata('errPass')) {
                                                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                                            ' . session()->getFlashdata('errPass') . '
                                                                        </div>';
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label required">Confirm Password</label>
                                                            <div class="col-sm-8">
                                                                <?php $isInvalidConfPass = (session()->getFlashdata('errConfPass')) ? 'is-invalid' : ''  ?>
                                                                <input class="form-control <?= $isInvalidConfPass ?>" name="conf_password" type="password" placeholder="">
                                                                <?php
                                                                if (session()->getFlashdata('errConfPass')) {
                                                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                                            ' . session()->getFlashdata('errConfPass') . '
                                                                        </div>';
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>

                                                        <center>
                                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                                        </center>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->