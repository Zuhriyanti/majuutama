<!-- Begin Page Content -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-dark">Data</h1>
    <!-- Page Heading -->
    <div class="card shadow">
        <div class="card-body">
            <?php if (session()->getFlashdata('pesan')) { ?>
                <div class="alert alert-success" id="alert-success" role="alert">
                    <?php echo session()->getFlashdata('pesan') ?>
                </div>
            <?php } ?>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100vw" cellspacing="">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Jumlah Pinjaman</th>
                            <th>Tanggal Meminjam</th>
                            <th>Jatuh Tempo</th>
                            <th>Jaminan</th>
                            <th>Deadline</th>
                            <th>Tanggal Lunas</th>
                            <th>Keterangan</th>
                            <th>Edit</th>
                            <!-- <th>Hapus</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include 'fungsi.php';
                        $no = 1;
                        $sekarang = time();
                        foreach ($pinjaman->getResultArray() as $raw) {
                        ?>
                            <tr>
                                <td>
                                    <div class="text-dark"><?= $no++ ?></div>
                                </td>
                                <td width="350px">
                                    <div class="text-dark"><?= $raw['nama_pengguna'] ?></div>
                                </td>
                                <td width="600px">
                                    <div class="text-dark"><?= $raw['alamat'] ?></div>
                                </td>
                                <td width="300px">
                                    <div class="text-dark"><?= rupiah($raw['jml_bayar']) ?></div>
                                </td>
                                <td width="350px">
                                    <div class="text-dark"><?= tgl_indo($raw['tgl_pinjaman']) ?></div>
                                </td>
                                <td width="350px">
                                    <div class="text-dark"><?= tgl_indo($raw['tgl_tenggat']) ?></div>
                                </td>
                                <td>
                                    <div class="text-dark"><?= $raw['jaminan'] ?></div>
                                </td>
                                <td>
                                    <?php if ($raw['ket'] == 'Lunas') { ?>
                                        <div> - </div>
                                    <?php } else { ?>
                                        <?php
                                        $waktu = strtotime($raw['tgl_tenggat']);
                                        $diff = $waktu - $sekarang;
                                        $doff = $sekarang - $waktu;
                                        if ($waktu >= $sekarang) {
                                        ?>
                                            <div class="bg-success text-white p-2 text-center">
                                                <?= floor($diff / (60 * 60 * 24)) .
                                                    ' Hari'; ?>
                                            </div>

                                        <?php } else { ?>
                                            <div class="bg-danger text-white p-2 text-center">
                                                <?= floor($diff / (60 * 60 * 24)) .
                                                    ' Hari'; ?>

                                            </div>

                                        <?php } ?>
                                    <?php } ?>
                                </td>
                                <td width="350px">
                                    <div class="text-dark">
                                        <?php if ($raw['ket'] == 'Lunas') { ?>
                                            <div><?= tgl_indo($raw['tgl_lunas']) ?></div>
                                        <?php } ?>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($raw['ket'] == 'Lunas') { ?>
                                        <div class="bg-success text-white py-2 text-center"><?= $raw['ket'] ?></div>
                                    <?php } else { ?>
                                        <div class="bg-danger text-white py-2 text-center"><?= $raw['ket'] ?></div>
                                    <?php } ?>
                                </td>
                                <td>
                                    <?php if ($raw['ket'] == 'Lunas') { ?>
                                        <button class="btn btn-xs btn-primary" style=" margin: 5px auto;" data-toggle="modal" data-target="#notaModal<?= $raw['id_pinjaman'] ?>"><i class=" fa fa-eye" title="Lihat Nota"></i></button>
                                    <?php } else { ?>
                                        <button class="btn btn-xs btn-warning" style=" margin: 5px auto;" data-toggle="modal" data-target="#pinjamanModal<?= $raw['id_transaksi'] ?>"><i class=" fa fa-edit"></i></button>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>


        </div>
    </div>
</div>
<!-- /.container-fluid -->

</div>

<!-- Pinjaman Modal-->
<?php foreach ($pinjaman->getResultArray() as $raw) { ?>
    <div class="modal fade" id="pinjamanModal<?= $raw['id_transaksi'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Update Lunas Pinjaman <?= $raw['nama_pengguna'] ?> </h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo base_url('data/update/' . $raw['id_transaksi']) ?>">
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label">Tanggal Pelunasan</label>
                            <div class="col-sm-8">
                                <input name="tgl_lunas" class="form-control" type="date" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label">Keterangan</label>
                            <div class="col-sm-8">
                                <input name="ket" class="form-control" type="text" required>
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Update</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php } ?>


<!-- Nota Modal-->
<?php foreach ($pinjaman->getResultArray() as $raw) { ?>
    <div class="modal fade" id="notaModal<?= $raw['id_pinjaman'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Nota</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body p-5">
                    <div class="mt-2 mb-5">
                        <h4 class="text-center font-weight-bold text-uppercase">Maju Utama</h4>
                        <h6 class="text-center">Dusun Endut Tojang Desa Lantan, Kec. Batukliang Utara, Kab. Lombok Tengah</h6>
                        <hr style="border-top: 2px dashed;" color="black">

                        <table>
                            <tbody>
                                <tr>
                                    <td>
                                        <b>Nama Peminjam</b>
                                    </td>
                                    <td>&nbsp;:</td>
                                    <td>&nbsp;<?= $raw['nama_pengguna'] ?></td>
                                </tr>
                                <tr>
                                    <td>
                                        <b>Alamat</b>
                                    </td>
                                    <td>&nbsp;:</td>
                                    <td>&nbsp;<?= $raw['alamat'] ?></td>
                                </tr>
                                <tr>
                                    <td>
                                        <b>Tanggal Peminjaman</b>
                                    </td>
                                    <td>&nbsp;:</td>
                                    <td>&nbsp;<?= tgl_indo($raw['tgl_pinjaman']) ?></td>
                                </tr>
                                <tr>
                                    <td>
                                        <b>Tanggal Pelunasan</b>
                                    </td>
                                    <td>&nbsp;:</td>
                                    <td>&nbsp;<?= tgl_indo($raw['tgl_lunas']) ?></td>
                                </tr>
                                <tr>
                                    <td>
                                        <b>Status</b>
                                    </td>
                                    <td>&nbsp;:</td>
                                    <td class="text-success font-weight-bold">&nbsp;<?= $raw['ket'] ?></td>
                                </tr>
                                <tr>
                                    <td>
                                        <b>Pinjaman</b>
                                    </td>
                                    <td>&nbsp;:</td>
                                    <td>&nbsp;<?= rupiah($raw['jml_pinjaman']) ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <b>Bunga Pinjaman</b>
                                    </td>
                                    <td>&nbsp;:</td>
                                    <td>&nbsp;<?= rupiah($raw['bunga']) ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <b>Total Pinjaman</b>
                                    </td>
                                    <td>&nbsp;:</td>
                                    <td>&nbsp;<p class="bg-light p-2 font-weight-bold"><?= rupiah($raw['jml_bayar']) ?></p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="float-right">
                        <table>
                            <tbody>
                                <tr>
                                    <td>Batukliang Utara,&nbsp;<?= tgl_indo($raw['tgl_lunas']) ?></td>
                                </tr>
                                <tr>
                                    <td><img width="150px" src="<?php echo base_url('ttd.png') ?>" alt="ttd"></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Sahabudin</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                </div>

            </div>
        </div>
    </div>
<?php } ?>