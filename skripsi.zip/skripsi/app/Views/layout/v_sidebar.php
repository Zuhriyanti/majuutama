 <!-- Sidebar -->
 <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

     <!-- Sidebar - Brand -->
     <a class="sidebar-brand d-flex align-items-center justify-content-center" href="home">
         <div class="sidebar-brand-icon rotate-n-15">
             <i class="fas fa-running"></i>
         </div>
         <div class="sidebar-brand-text mx-3">MAJU UTAMA</div>
     </a>

     <?php if (session()->user == 'admin') : ?>
         <!-- Divider -->
         <hr class="sidebar-divider my-0">
         <li class="nav-item">
             <a class="nav-link" href="/home">
                 <i class="fas fa-fw fa-window-restore"></i>
                 <span>Dashboard</span></a>
             <hr class="sidebar-divider my-0">
         <li class="nav-item">
             <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                 <i class="fas fa-fw fa-user"></i>
                 <span>Kelola Pengguna</span>
             </a>
             <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                 <div class="bg-white py-2 collapse-inner rounded">
                     <a class="collapse-item" href="/tambah_pengguna">Pengguna Baru</a>
                     <a class="collapse-item" href="/pengguna">Daftar Pengguna</a>
                 </div>
             </div>
         </li>
         <hr class="sidebar-divider my-0">
         <li class="nav-item">
             <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                 <i class="fas fa-fw fa-money-bill-alt"></i>
                 <span>Pinjaman</span>
             </a>
             <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                 <div class="bg-white py-2 collapse-inner rounded">
                     <a class="collapse-item" href="/tambah">Pinjaman Baru</a>
                     <a class="collapse-item" href="/data">Daftar Pinjaman</a>
                 </div>
             </div>
         </li>

         <hr class="sidebar-divider my-0">
         <li class="nav-item">
             <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUnggulan" aria-expanded="true" aria-controls="collapseUtilities">
                 <i class="fas fa-fw fa-star"></i>
                 <span>Unggulan</span>
             </a>
             <div id="collapseUnggulan" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                 <div class="bg-white py-2 collapse-inner rounded">
                     <a class="collapse-item" href="/tambah_unggulan">Unggulan Baru</a>
                     <a class="collapse-item" href="/unggulan">Daftar Unggulan</a>
                 </div>
             </div>
         </li>

         <hr class="sidebar-divider my-0">

         <hr class="sidebar-divider my-0">
         <li class="nav-item">
             <a class="nav-link collapsed" href="/laporan" aria-expanded="true" aria-controls="collapseUtilities">
                 <i class="fas fa-fw fa-book"></i>
                 <span>Laporan</span>
             </a>
         </li>
         <hr class="sidebar-divider my-0">
     <?php endif; ?>

     <!-- user access -->
     <?php if (session()->user == 'user') : ?>
         <hr class="sidebar-divider my-0">
         <li class="nav-item">
             <a class="nav-link" href="/home">
                 <i class="fas fa-fw fa-window-restore"></i>
                 <span>Dashboard</span></a>
             <hr class="sidebar-divider my-0">
             <a class="nav-link" href="/user_data">
                 <i class="fas fa-fw fa-money-bill-alt"></i>
                 <span>Data Pinjaman</span></a>
             <hr class="sidebar-divider my-0">
             <a class="nav-link" href="/user_unggulan">
                 <i class="fas fa-fw fa-star"></i>
                 <span>Data Unggulan</span></a>
             <hr class="sidebar-divider my-0">
         <?php endif; ?>

         <!-- Nav Item - Dashboard -->
         <li class="nav-item">
             <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
                 <i class="fas fa-fw fa-sign-out-alt"></i>
                 <span>Keluar</span></a>
         </li>



         <!-- Divider -->
         <hr class="sidebar-divider d-none d-md-block">

         <!-- Sidebar Toggler (Sidebar) -->
         <div class="text-center d-none d-md-inline">
             <button class="rounded-circle border-0" id="sidebarToggle"></button>
         </div>

 </ul>
 <!-- End of Sidebar -->