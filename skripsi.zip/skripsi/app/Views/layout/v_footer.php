<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; 2022</span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Yakin Akan Keluar?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Pilih Keluar Jika Anda Yakin</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                <a class="btn btn-primary" href="<?php echo site_url('home/logout') ?>">Keluar</a>
            </div>
        </div>
    </div>
</div>
<!-- Bootstrap core JavaScript-->
<script src="<?= base_url(); ?>/template/vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url(); ?>/template/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?= base_url(); ?>/template/vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?= base_url(); ?>/template/js/sb-admin-2.min.js"></script>
<!-- Page level plugins -->
<script src="<?= base_url(); ?>/template/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url(); ?>/template/vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?= base_url(); ?>/template/js/demo/datatables-demo.js"></script>



<script>
    window.setTimeout(function() {
        $(".alert").fadeTo(500, 0).slideUp(500, function() {
            $(this).remove();
        });
    }, 3000);
</script>
<script>
    $("#pinjaman").keyup(function() {
        var a = parseInt($("#pinjaman").val());
        var b = a * 0.1;
        var c = parseInt($("#bunga").val(b));
        var d = a + b;
        var e = d;
        $("#total").val(e);
    });
</script>
<script>
    function jumlah() {
        var a = document.getElementById('hari').value;
        var b = document.getElementById('tgl1').value;
        var hari = a * 24 * 60 * 60 * 1000;

        var hariKedepan = new Date(new Date(b).getTime() + (hari));

        document.getElementById('tgl2').value = hariKedepan.toISOString().slice(0, 10);
    }
</script>


</body>

</html>