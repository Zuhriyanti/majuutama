<!DOCTYPE html>
<html lang="en">

<head>
    <title>Maju Utama</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">


    <!-- Custom fonts for this template-->
    <link href="<?= base_url(); ?>/template/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template-->
    <link href="<?= base_url(); ?>/template/css/sb-admin-2.min.css" rel="stylesheet">
    <!-- Custom styles for this page -->
    <link href="<?= base_url(); ?>/template/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body onLoad="window.print()">
    <div class="text-dark">
        <?php
        include 'fungsi.php'
        ?>
        <br>
        <table style="text-align: center; width:100%; border-collapse:collapse;" border="0">
            <tr>
                <td>
                    <table style="width: 100%; text-align:center;" border="0">
                        <tr style="text-align: center;">
                            <td>

                                <h1>Maju Utama</h1>
                                <h4>Dusun Endut Tojang Desa Lantan, Kec. Batukliang Utara, Kab. Lombok Tengah</h4>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <br>
                    <table style="width: 100%; text-align:center;" border="0">
                        <tr style="text-align: center;">
                            <td>
                                <h5><u>Laporan Data Pinjaman Unggulan</u></h5><br>
                                Periode : <?= tgl_indo($tgl1)  . " s/d " .  tgl_indo($tgl2) ?>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <br>
                                <center>
                                    <table border="1" cellpadding="5" style="border-collapse: collapse; border: 1px solid #000; text-align:center; width:90%;">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Peminjam</th>
                                                <th>Alamat Peminjam</th>
                                                <th>Tanggal Pelunasan</th>
                                                <th>Jumlah Pinjaman</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $no = 1;
                                            $totalPinjaman = 0;
                                            foreach ($dataLaporan->getResultArray() as $raw) {
                                                if ($raw['ket'] == "Lunas") {
                                                    $totalPinjaman += $raw['jml_bayar'];
                                                } else {
                                                    null;
                                                }
                                            ?>
                                                <?php if ($raw['ket'] == 'Belum Lunas') { ?>
                                                    <tr></tr>
                                                <?php } else { ?>
                                                    <tr>
                                                        <td><?= $no++ ?></td>
                                                        <td><?= $raw['nama_pengguna'] ?></td>
                                                        <td><?= $raw['alamat'] ?></td>
                                                        <td><?= tgl_indo($raw['tgl_lunas']) ?></td>
                                                        <td><?= rupiah($raw['jml_bayar']) ?></td>
                                                    </tr>
                                                <?php } ?>
                                            <?php } ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th colspan="4">Jumlah Total</th>
                                                <td><?= rupiah($totalPinjaman) ?></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </center>
                            </td>
                        </tr>
                    </table>
                    <br>
                </td>
            </tr>
        </table>
        <div class="container">

            <div class="float-right">
                <div>
                    Batukliang Utara <?php $tgl = date('Y-m-d');
                                        echo tgl_indo($tgl); ?>
                </div>

                <div>
                    <img width="150px" src="<?php echo base_url('ttd.png') ?>" alt="ttd">
                </div>

                Sahabudin

            </div>

        </div>
    </div>
</body>

<!-- Bootstrap core JavaScript-->
<script src="<?= base_url(); ?>/template/vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url(); ?>/template/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?= base_url(); ?>/template/vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?= base_url(); ?>/template/js/sb-admin-2.min.js"></script>
<!-- Page level plugins -->
<script src="<?= base_url(); ?>/template/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url(); ?>/template/vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?= base_url(); ?>/template/js/demo/datatables-demo.js"></script>

</html>