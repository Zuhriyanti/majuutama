<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Tambah Data Unggulan</h1>
    <div class="card">
        <div class="card-body">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-7">
                        <div class="card o-hidden border-0 shadow-lg my-2">
                            <div class="card-body p-0">
                                <div class="row">
                                    <div class="col-lg-5 d-none d-lg-block bg-register-image"></div>
                                    <div class="col-md-12">
                                        <div class="p-5">
                                            <div class="text-dark">
                                                <div class="col-12">

                                                    <h4 class="text-center mt-3">Masukkan Data Pinjaman Unggulan</h4><br>
                                                    <form action="<?php echo base_url('tambah_unggulan/save_pinjaman') ?>">
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Nama Peminjam</label>
                                                            <div class="col-sm-8">
                                                                <?php $isInvalidPengguna = (session()->getFlashdata('errIdUser')) ? 'is-invalid' : ''  ?>
                                                                <select multiple name="id_user" class="form-control <?= $isInvalidPengguna ?>">
                                                                    <?php foreach ($pengguna->getResultArray() as $raw) { ?>
                                                                        <option value="<?= $raw['id_user'] ?>"><?= $raw['nama_pengguna'] ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <?php
                                                                if (session()->getFlashdata('errIdUser')) {
                                                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                                            ' . session()->getFlashdata('errIdUser') . '
                                                                        </div>';
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>

                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Jumlah Pinjaman</label>
                                                            <div class="col-sm-8">
                                                                <?php $isInvalidPinjaman = (session()->getFlashdata('errPinjaman')) ? 'is-invalid' : ''  ?>
                                                                <input name="jml_pinjaman" class="form-control <?= $isInvalidPinjaman ?>" type="text" placeholder="">
                                                                <?php
                                                                if (session()->getFlashdata('errPinjaman')) {
                                                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                                            ' . session()->getFlashdata('errPinjaman') . '
                                                                        </div>';
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Tanggal Pinjaman</label>
                                                            <div class="col-sm-8">
                                                                <?php $isInvalidTglPinjaman = (session()->getFlashdata('errTglPinjaman')) ? 'is-invalid' : ''  ?>
                                                                <input class="form-control <?= $isInvalidTglPinjaman ?>" id="tgl1" name="tgl_pinjaman" type="date" onkeyup="jumlah()">
                                                                <?php
                                                                if (session()->getFlashdata('errTglPinjaman')) {
                                                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                                            ' . session()->getFlashdata('errTglPinjaman') . '
                                                                        </div>';
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Hari</label>
                                                            <div class="col-sm-8">
                                                                <?php $isInvalidHari = (session()->getFlashdata('errHari')) ? 'is-invalid' : ''  ?>
                                                                <input id="hari" name="hari" class="form-control <?= $isInvalidHari ?>" type="number" onkeyup="jumlah()">
                                                                <?php
                                                                if (session()->getFlashdata('errHari')) {
                                                                    echo '<div id="validationServer03Feedback" class="invalid-feedback">
                                                                            ' . session()->getFlashdata('errHari') . '
                                                                        </div>';
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label"> Tanggal Jatuh Tempo</label>
                                                            <div class="col-sm-8">
                                                                <input class="form-control" id="tgl2" name="tgl_tenggat" type="date" placeholder="" readonly>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Jaminan</label>
                                                            <div class="col-sm-8">
                                                                <input class="form-control" name="jaminan" type="text" placeholder="">
                                                            </div>
                                                        </div>

                                                        <center class="mt-5">
                                                            <button type="submit" class="btn btn-success">Simpan</button>
                                                            <a href="/data" class="btn btn-danger">Kembali</a>
                                                        </center>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->