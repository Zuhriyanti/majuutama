<?php
function userLogin()
{
    $db = \Config\Database::connect();
    return $db->table('tbl_user')->where('id_user', session('id_user'))->get()->getRow();
}

function countData($table)
{
    $db = \Config\Database::connect();
    return $db->table($table)->countAllResults();
}

function countUserData($table)
{
    $db = \Config\Database::connect();
    return $db->table($table)->where('id_user', session('id_user'))->countAllResults();
}
