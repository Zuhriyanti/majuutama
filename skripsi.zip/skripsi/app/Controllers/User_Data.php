<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_User_Data;
// use App\Models\M_Transaksi;

class User_Data extends Controller
{
    // protected $transaksi;

    // function __construct()
    // {
    //     $this->transaksi = new M_Transaksi();
    // }

    public function index()
    {
        $model = new M_User_Data();
        $data = [
            'pinjaman' => $model->getAllData()
        ];
        echo view('layout/v_header', $data);
        echo view('layout/v_sidebar');
        echo view('layout/v_topbar');
        echo view('user/data/index', $data);
        echo view('layout/v_footer');
    }
}
