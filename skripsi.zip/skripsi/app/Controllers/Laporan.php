<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_Laporan_Pinjaman;
use App\Models\M_Laporan_Unggulan;

class Laporan extends Controller
{
    public function index()
    {

        echo view('layout/v_header');
        echo view('layout/v_sidebar');
        echo view('layout/v_topbar');
        echo view('laporan/index');
        echo view('layout/v_footer');
    }

    public function cetak_pinjaman()
    {
        $tgl1 = $this->request->getPost('tgl1');
        $tgl2 = $this->request->getPost('tgl2');

        $cetakPinjaman = new M_Laporan_Pinjaman();

        $dataLaporan = $cetakPinjaman->laporanPerPeriode($tgl1, $tgl2);

        $data = [
            'dataLaporan' => $dataLaporan,
            'tgl1' => $tgl1,
            'tgl2' => $tgl2
        ];

        return view('laporan/cetakLaporanPinjaman', $data);
    }

    public function cetak_unggulan()
    {
        $tgl1 = $this->request->getPost('tgl1');
        $tgl2 = $this->request->getPost('tgl2');

        $cetakUnggulan = new M_Laporan_Unggulan();

        $dataLaporan = $cetakUnggulan->laporanPerPeriode($tgl1, $tgl2);

        $data = [
            'dataLaporan' => $dataLaporan,
            'tgl1' => $tgl1,
            'tgl2' => $tgl2
        ];

        return view('laporan/cetakLaporanUnggulan', $data);
    }
}
