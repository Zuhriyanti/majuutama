<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_Data;
use App\Models\M_Transaksi;

class Data extends Controller
{
    protected $transaksi;

    function __construct()
    {
        $this->transaksi = new M_Transaksi();
    }

    public function index()
    {
        $model = new M_Data();
        $data = [
            'pinjaman' => $model->getAllData(),
        ];
        echo view('layout/v_header', $data);
        echo view('layout/v_sidebar');
        echo view('layout/v_topbar');
        echo view('data/index', $data);
        echo view('layout/v_footer');
    }

    public function update($id_transaksi)
    {
        $this->transaksi->update($id_transaksi, [
            'tgl_lunas' => $this->request->getVar('tgl_lunas'),
            'ket' => $this->request->getVar('ket')
        ]);
        session()->setFlashdata('pesan', 'Update lunas berhasil');
        return redirect()->to('/data');
    }
}
