<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_User_Unggulan;

class User_Unggulan extends Controller
{


    public function index()
    {
        $model = new M_User_Unggulan();
        $data = [
            'unggulan' => $model->getAllData()
        ];
        echo view('layout/v_header', $data);
        echo view('layout/v_sidebar');
        echo view('layout/v_topbar');
        echo view('/user/unggulan/index');
        echo view('layout/v_footer');
    }
}
