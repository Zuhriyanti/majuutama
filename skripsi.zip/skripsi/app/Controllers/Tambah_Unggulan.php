<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_Tambah_Unggulan;
use App\Models\M_Transaksi_Unggulan;
use App\Models\M_Pengguna;

class Tambah_Unggulan extends Controller
{

    protected $tambahUnggulan;
    protected $transaksi;

    function __construct()
    {
        $this->tambahUnggulan = new M_Tambah_Unggulan();
        $this->transaksi = new M_Transaksi_Unggulan();
    }


    public function index()
    {
        $modelPengguna = new M_Pengguna();
        $data = [
            'judul' => 'Tambah',
            'pengguna' => $modelPengguna->getDataSelect()
        ];
        echo view('layout/v_header');
        echo view('layout/v_sidebar');
        echo view('layout/v_topbar');
        echo view('tambah_unggulan/index',  $data);
        echo view('layout/v_footer');
    }

    public function save_pinjaman()
    {
        $validation = \Config\Services::validation();
        $valid = $this->validate([
            'id_user' => [
                'label' => 'Nama Peminjam',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} tidak boleh kosong'
                ]
            ],
            'jml_pinjaman' => [
                'label' => 'Jumlah Pinjaman',
                'rules' => 'required|numeric',
                'errors' => [
                    'required' => '{field} tidak boleh kosong',
                    'numeric'  => '{field} tidak menggunakan titik / koma'
                ]
            ],
            'tgl_pinjaman' => [
                'label' => 'Tanggal Pinjaman',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} tidak boleh kosong'
                ]
            ],
            'hari' => [
                'label' => 'Hari',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} tidak boleh kosong'
                ]
            ],

        ]);
        if (!$valid) {
            $sessError = [
                'errIdUser' => $validation->getError('id_user'),
                'errPinjaman' => $validation->getError('jml_pinjaman'),
                'errTglPinjaman' => $validation->getError('tgl_pinjaman'),
                'errHari' => $validation->getError('hari'),
            ];
            session()->setFlashdata($sessError);
            return redirect('')->to('/tambah_unggulan');
        } else {
            // Insert tbl Transaksi
            $dataTransaksi = [
                'jml_bayar' => $this->request->getVar('jml_pinjaman'),
                'tgl_lunas' => $this->request->getVar('tgl_pinjaman'),
                'ket' => 'Belum Lunas',
            ];
            $this->transaksi->insert($dataTransaksi);

            $transaksiId = $this->transaksi->insertID();
            // insert tbl Unggulan
            $dataPinjaman = [
                'id_user' => $this->request->getVar('id_user'),
                'id_transaksi' => $transaksiId,
                'jml_pinjaman' => $this->request->getVar('jml_pinjaman'),
                'tgl_pinjaman' => $this->request->getVar('tgl_pinjaman'),
                'tgl_tenggat' => $this->request->getVar('tgl_tenggat'),
                'jaminan' => $this->request->getVar('jaminan')
            ];
            $this->tambahUnggulan->insert($dataPinjaman);
            session()->setFlashdata('pesan', 'Data Pinjaman telah ditambahkan');
            return redirect()->to('/unggulan');
        }
    }
}
