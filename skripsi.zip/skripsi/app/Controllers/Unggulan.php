<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_Unggulan;
use App\Models\M_Transaksi_Unggulan;

class Unggulan extends Controller
{
    protected $transaksi;

    function __construct()
    {
        $this->transaksi = new M_Transaksi_Unggulan();
    }

    public function index()
    {
        $model = new M_Unggulan();
        $data = [
            'unggulan' => $model->getAllData()
        ];
        echo view('layout/v_header', $data);
        echo view('layout/v_sidebar');
        echo view('layout/v_topbar');
        echo view('unggulan/index');
        echo view('layout/v_footer');
    }

    public function update($id_transaksi)
    {
        $this->transaksi->update($id_transaksi, [
            'tgl_lunas' => $this->request->getVar('tgl_lunas'),
            'ket' => $this->request->getVar('ket')
        ]);
        session()->setFlashdata('pesan', 'Update lunas berhasil');
        return redirect()->to('/unggulan');
    }
}
