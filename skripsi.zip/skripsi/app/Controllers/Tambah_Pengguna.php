<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_Tambah_Pengguna;

class Tambah_Pengguna extends Controller
{
    protected $tambahPengguna;

    function __construct()
    {
        $this->tambahPengguna = new M_Tambah_Pengguna();
    }

    public function index()
    {
        $data = [
            'judul' => 'Tambah Pengguna'
        ];
        echo view('layout/v_header', $data);
        echo view('layout/v_sidebar');
        echo view('layout/v_topbar');
        echo view('tambah_pengguna/index');
        echo view('layout/v_footer');
    }

    public function save_registration()
    {
        $nama_pengguna = $this->request->getPost('nama_pengguna');
        $no_ktp = $this->request->getPost('no_ktp');
        $ttl = $this->request->getPost('ttl');
        $alamat = $this->request->getPost('alamat');
        $no_hp = $this->request->getPost('no_hp');
        $user = $this->request->getPost('user');
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        $conf_password = $this->request->getPost('conf_password');

        $validation = \Config\Services::validation();
        $valid = $this->validate([
            'nama_pengguna' => [
                'label' => 'Nama Lengkap',
                'rules' => 'required|is_unique[tbl_user.nama_pengguna]',
                'errors' => [
                    'required' => '{field} tidak boleh kosong',
                    'is_unique' => '{field} sudah terdaftar !!!'
                ]
            ],
            'no_ktp' => [
                'label' => 'NIK/KTP',
                'rules' => 'required|max_length[16]|is_unique[tbl_user.no_ktp]',
                'errors' => [
                    'required' => '{field} tidak boleh kosong',
                    'max_length' => '{field} tidak boleh lebih dari 16 karakter',
                    'is_unique' => '{field} sudah terdaftar !!!'
                ]
            ],
            'ttl' => [
                'label' => 'Tempat, Tanggal Lahir',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} tidak boleh kosong'
                ]
            ],
            'alamat' => [
                'label' => 'Alamat',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} tidak boleh kosong'
                ],
            ],
            'no_hp' => [
                'label' => 'Nomor HP',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} tidak boleh kosong'
                ],
            ],
            'user' => [
                'label' => 'User Level',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} tidak boleh kosong'
                ]
            ],
            'email' => [
                'label' => 'Email',
                'rules' => 'required|valid_email|is_unique[tbl_user.email]',
                'errors' => [
                    'required' => '{field} tidak boleh kosong',
                    'is_unique' => '{field} sudah terdaftar !!!'
                ]
            ],
            'password' => [
                'label' => 'Password',
                'rules' => 'required|min_length[8]',
                'errors' => [
                    'required' => '{field} tidak boleh kosong',
                    'min_length' => '{field} tidak boleh kurang dari 8 karakter'
                ]
            ],
            'conf_password' => [
                'label' => 'Confirm Password',
                'rules' => 'required|matches[password]',
                'errors' => [
                    'required' => '{field} tidak boleh kosong',
                    'matches' => '{field} tidak sama'
                ]
            ],
        ]);
        if (!$valid) {
            $sessError = [
                'errNama' => $validation->getError('nama_pengguna'),
                'errNIK' => $validation->getError('no_ktp'),
                'errTtl' => $validation->getError('ttl'),
                'errAlamat' => $validation->getError('alamat'),
                'errHp' => $validation->getError('no_hp'),
                'errUser' => $validation->getError('user'),
                'errEmail' => $validation->getError('email'),
                'errPass' => $validation->getError('password'),
                'errConfPass' => $validation->getError('conf_password'),
            ];
            session()->setFlashdata('email', $email);
            session()->setFlashdata('nama_pengguna', $nama_pengguna);
            session()->setFlashdata('no_ktp', $no_ktp);
            session()->setFlashdata('alamat', $alamat);
            session()->setFlashdata('no_hp', $no_hp);
            session()->setFlashdata($sessError);
            return redirect()->to('/tambah_pengguna');
        } else {
            $ModelPengguna = new M_Tambah_Pengguna();
            $data = [
                'nama_pengguna' => $this->request->getVar('nama_pengguna'),
                'no_ktp' => $this->request->getVar('no_ktp'),
                'alamat' => $this->request->getVar('alamat'),
                'no_hp' => $this->request->getVar('no_hp'),
                'ttl'    => $this->request->getVar('ttl'),
                'email' => $this->request->getVar('email'),
                'user' => $this->request->getVar('user'),
                'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT)
            ];
            $ModelPengguna->save($data);
            session()->setFlashdata('pesan', 'Pengguna berhasil ditambahkan');
            return redirect()->to('pengguna');
        }
    }

    public function edit($id_user)
    {
        $ModelPengguna = new M_Tambah_Pengguna();
        $data = [
            'Edit' => 'Edit Pengguna',
            'pengguna' => $ModelPengguna->find($id_user)
        ];
        echo view('layout/v_header', $data);
        echo view('layout/v_sidebar');
        echo view('layout/v_topbar');
        echo view('edit_pengguna/index', $data);
        echo view('layout/v_footer');
    }

    public function update($id_user)
    {
        $this->tambahPengguna->update($id_user, [
            'nama_pengguna' => $this->request->getVar('nama_pengguna'),
            'no_ktp' => $this->request->getVar('no_ktp'),
            'alamat' => $this->request->getVar('alamat'),
            'no_hp' => $this->request->getVar('no_hp'),
            'ttl'    => $this->request->getVar('ttl'),
            'email' => $this->request->getVar('email'),
            'user' => $this->request->getVar('user'),

        ]);
        session()->setFlashdata('pesan', 'Update data user berhasil');
        return redirect()->to('/pengguna');
    }
}
