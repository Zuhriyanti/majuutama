<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\M_Login_Admin;


class Login extends BaseController
{

    public function index()
    {
        return view('login/index');
    }

    public function loginCheck()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $validation = \Config\Services::validation();

        $valid = $this->validate([
            'email' => [
                'label' => 'Email',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} tidak boleh kosong'
                ]
            ],
            'password' => [
                'label' => 'Password',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} tidak boleh kosong'
                ]
            ],
        ]);
        if (!$valid) {
            $sessError = [
                'errEmail' => $validation->getError('email'),
                'errPassword' => $validation->getError('password')
            ];
            session()->setFlashdata($sessError);
            return redirect()->to('/');
        } else {
            $modelLogin = new M_Login_Admin();
            $cekUserLogin = $modelLogin->find($email);
            if ($cekUserLogin == null) {
                $sessError = [
                    'errEmail' => 'Maaf email belum terdaftar'
                ];
                session()->setFlashdata($sessError);
                return redirect()->to('/');
            } else {
                $passwordUser = $cekUserLogin['password'];
                if (password_verify($password, $passwordUser)) {
                    // continue
                    $user = $cekUserLogin['user'];
                    $id  = $cekUserLogin['id_user'];

                    $saveSession = [
                        'id_user' => $id,
                        'email' => $cekUserLogin['email'],
                        // 'password' => $cekUserLogin['password'],
                        'nama_pengguna' => $cekUserLogin['nama_pengguna'],
                        'user' => $user,
                    ];
                    session()->set($saveSession);
                    return redirect()->to('/home');
                } else {
                    $sessError = [
                        'errPassword' => 'Password yang anda masukkan salah !!!'
                    ];
                    session()->setFlashdata('email', $email);
                    session()->setFlashdata($sessError);
                    return redirect()->to('/');
                }
            }
        }
    }
}
