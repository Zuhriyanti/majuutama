<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_Deadline;

class Deadline extends Controller
{
    public function index()
    {
        $model = new M_Deadline();
        $data = [
            'tb_peminjaman' => $model->getAllData()
        ];
        echo view('layout/v_header', $data);
        echo view('layout/v_sidebar');
        echo view('layout/v_topbar');
        echo view('deadline/index');
        echo view('layout/v_footer');
    }
}
