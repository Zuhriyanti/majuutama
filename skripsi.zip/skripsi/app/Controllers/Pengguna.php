<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_Pengguna;

class Pengguna extends Controller
{
    protected $pengguna;

    function __construct()
    {
        $this->pengguna = new M_Pengguna();
    }

    public function index()
    {
        $modelPengguna = new M_Pengguna();

        $data = [
            'judul' => 'Pengguna',
            'pengguna' => $modelPengguna->getAllData()
        ];
        echo view('layout/v_header', $data);
        echo view('layout/v_sidebar');
        echo view('layout/v_topbar');
        echo view('pengguna/index', $data);
        echo view('layout/v_footer');
    }

    public function delete($id_user)
    {
        $modelPengguna = new M_pengguna();
        $modelPengguna->delete($id_user);
        session()->setFlashdata('pesan', 'Pengguna berhasil dihapus!!');
        return redirect()->to('/pengguna');
    }

    public function reset($id_user)
    {
        $validation = \Config\Services::validation();
        $valid = $this->validate([
            'password' => [
                'label' => 'Password',
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} tidak boleh kosong'
                ]
            ],
            'conf_password' => [
                'label' => 'Confirm Password',
                'rules' => 'required|matches[password]',
                'errors' => [
                    'required' => '{field} tidak boleh kosong',
                    'matches' => '{field} tidak sama'
                ]
            ],
        ]);
        if (!$valid) {
            $sessError = [
                'errPass' => $validation->getError('password'),
                'errConfPass' => $validation->getError('conf_password'),
            ];
            session()->setFlashdata($sessError);
            session()->setFlashdata('gagal', 'Ada kesalahan, mohon periksa kembali !!');
            return redirect()->to('pengguna');
        } else {
            $this->pengguna->update($id_user, [
                'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT)
            ]);
            session()->setFlashdata('pesan', 'Password berhasil direset');
            return redirect()->to('/pengguna');
        }
    }
}
