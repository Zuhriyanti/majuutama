<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Transaksi extends Model
{
    protected $table    = 'tbl_transaksi';
    protected $primaryKey = 'id_transaksi';
    protected $allowedFields =  [
        'id_transaksi', 'jml_bayar', 'ket', 'bunga', 'tgl_lunas'
    ];
    // public function __construct()
    // {
    //     $this->db = db_connect();
    // }
    // public function getAllData()
    // {
    //     return $this->db->table('tb_peminjaman')->get();
    // }
}
