<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Laporan_Unggulan extends Model
{
    public function laporanPerPeriode($tgl1, $tgl2)
    {
        $query = $this->db->table('tbl_unggulan')
            ->where('tgl_pinjaman >=', $tgl1)
            ->where('tgl_pinjaman <=', $tgl2)
            ->join('tbl_user', 'tbl_unggulan.id_user = tbl_user.id_user')
            ->join('tbl_transaksi_unggul', 'tbl_unggulan.id_transaksi = tbl_transaksi_unggul.id_transaksi')
            ->get();
        return $query;
    }
}
