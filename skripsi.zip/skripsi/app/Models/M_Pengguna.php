<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Pengguna extends Model
{

    protected $table    = 'tbl_user';
    protected $primaryKey = 'id_user';
    protected $allowedFields =  [
        'id_user', 'nama_pengguna', 'alamat', 'ttl', 'no_ktp', 'email', 'password', 'user'
    ];

    public function __construct()
    {
        $this->db = db_connect();
    }
    public function getAllData()
    {
        $query = $this->db->table('tbl_user')
            ->orderBy('id_user', 'DESC')
            ->get();
        return $query;
    }

    public function getDataSelect()
    {
        $query = $this->db->table('tbl_user')
            ->orderBy('nama_pengguna', 'ASC')
            ->get();
        return $query;
    }
}
