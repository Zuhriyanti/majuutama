<?php

namespace App\Models;

use CodeIgniter\Model;

class M_User_Unggulan extends Model
{
    public function __construct()
    {
        $this->db = db_connect();
    }
    public function getAllData()
    {
        $query =  $this->db->table('tbl_unggulan')
            ->join('tbl_user', 'tbl_unggulan.id_user = tbl_user.id_user')
            ->join('tbl_transaksi_unggul', 'tbl_unggulan.id_transaksi = tbl_transaksi_unggul.id_transaksi')
            ->orderBy('id_unggulan', 'DESC')
            ->get();
        return $query;
    }
}
