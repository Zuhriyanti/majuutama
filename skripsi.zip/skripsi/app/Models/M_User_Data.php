<?php

namespace App\Models;

use CodeIgniter\Model;

class M_User_Data extends Model
{
    public function __construct()
    {
        $this->db = db_connect();
    }
    public function getAllData()
    {
        // $id = $this->session->userdata('id_user');
        $query =  $this->db->table('tbl_pinjaman')
            ->join('tbl_user', 'tbl_pinjaman.id_user = tbl_user.id_user')
            ->join('tbl_transaksi', 'tbl_pinjaman.id_transaksi = tbl_transaksi.id_transaksi')
            ->orderBy('id_pinjaman', 'DESC')
            ->get();
        return $query;
    }
}
