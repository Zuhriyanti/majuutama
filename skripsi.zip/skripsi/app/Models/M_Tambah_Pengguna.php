<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Tambah_Pengguna extends Model
{
    protected $table    = 'tbl_user';
    protected $primaryKey = 'id_user';
    protected $allowedFields =  [
        'nama_pengguna', 'alamat', 'ttl', 'no_ktp', 'email', 'password', 'user', 'no_hp'
    ];
    // public function save_registration($data)
    // {
    //     $this->db->table('tbl_user')->insert($data);
    // }
}
