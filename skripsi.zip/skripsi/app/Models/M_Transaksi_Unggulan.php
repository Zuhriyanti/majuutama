<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Transaksi_Unggulan extends Model
{
    protected $table    = 'tbl_transaksi_unggul';
    protected $primaryKey = 'id_transaksi';
    protected $allowedFields =  [
        'id_transaksi', 'jml_bayar', 'ket', 'tgl_lunas'
    ];
}
