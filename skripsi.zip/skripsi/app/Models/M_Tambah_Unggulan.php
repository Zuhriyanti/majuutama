<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Tambah_Unggulan extends Model
{
    protected $table    = 'tbl_unggulan';
    protected $primaryKey = 'id_unggulan';
    protected $allowedFields =  [
        'id_unggulan', 'id_user', 'id_transaksi', 'jml_pinjaman', 'tgl_pinjaman', 'tgl_tenggat', 'jaminan'
    ];
}
