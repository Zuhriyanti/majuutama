<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Laporan_Pinjaman extends Model
{
    public function laporanPerPeriode($tgl1, $tgl2)
    {
        $query = $this->db->table('tbl_pinjaman')
            ->where('tgl_pinjaman >=', $tgl1)
            ->where('tgl_pinjaman <=', $tgl2)
            ->join('tbl_user', 'tbl_pinjaman.id_user = tbl_user.id_user')
            ->join('tbl_transaksi', 'tbl_pinjaman.id_transaksi = tbl_transaksi.id_transaksi')
            ->get();
        return $query;
    }
}
