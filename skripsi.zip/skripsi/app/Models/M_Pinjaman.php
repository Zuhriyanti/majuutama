<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Pinjaman extends Model
{
    protected $table    = 'tbl_pinjaman';
    protected $primaryKey = 'id_pinjaman';
    protected $allowedFields =  [
        'id_pinjaman', 'id_user', 'id_transaksi', 'jml_pinjaman', 'tgl_pinjaman', 'tgl_tenggat', 'jaminan'
    ];
    // public function __construct()
    // {
    //     $this->db = db_connect();
    // }
    // public function getAllData()
    // {
    //     return $this->db->table('tb_peminjaman')->get();
    // }
}
