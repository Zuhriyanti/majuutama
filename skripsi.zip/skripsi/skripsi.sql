-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2022 at 01:36 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skripsi`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pinjaman`
--

CREATE TABLE `tbl_pinjaman` (
  `id_pinjaman` int(10) NOT NULL,
  `id_user` int(10) NOT NULL,
  `id_transaksi` int(11) NOT NULL,
  `jml_pinjaman` varchar(60) NOT NULL,
  `tgl_pinjaman` date NOT NULL,
  `tgl_tenggat` date NOT NULL,
  `jaminan` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_pinjaman`
--

INSERT INTO `tbl_pinjaman` (`id_pinjaman`, `id_user`, `id_transaksi`, `jml_pinjaman`, `tgl_pinjaman`, `tgl_tenggat`, `jaminan`) VALUES
(10, 18, 8, '50000', '2022-07-01', '2022-09-29', '-'),
(11, 17, 9, '2500000', '2022-07-30', '2022-09-28', 'BPKB'),
(12, 19, 10, '4550000', '2022-07-31', '2022-10-29', 'BPKB'),
(13, 22, 12, '350000', '2022-07-31', '2022-08-30', 'Sepeda'),
(14, 22, 24, '150000', '2022-08-01', '2022-09-10', 'Sertifikat'),
(15, 23, 25, '1000000', '2022-08-02', '2022-10-01', 'STNK'),
(16, 25, 26, '1000000', '2022-08-02', '2022-10-31', '-'),
(17, 25, 27, '1000000', '2022-08-02', '2023-01-29', 'hp'),
(18, 25, 28, '100000', '2022-01-03', '2022-04-03', 'hp'),
(19, 36, 29, '250000', '2022-08-03', '2022-10-02', '-'),
(20, 24, 30, '250000', '2022-08-03', '2022-10-02', '-'),
(21, 35, 31, '250000', '2022-08-03', '2022-11-01', '-'),
(22, 27, 32, '250000', '2022-08-03', '2022-11-01', '-'),
(23, 26, 33, '250000', '2022-08-03', '2022-11-01', '-'),
(24, 21, 34, '9000000', '2022-08-03', '2022-11-01', '-'),
(25, 35, 35, '100000', '2022-08-03', '2022-11-01', '-'),
(26, 26, 36, '250000', '2022-08-04', '2022-11-02', '-'),
(27, 21, 37, '250000', '2022-08-04', '2022-11-02', '-'),
(28, 17, 38, '250000', '2022-08-04', '2022-11-02', '-'),
(29, 20, 39, '250000', '2022-08-04', '2022-11-02', '-'),
(30, 23, 40, '250000', '2022-08-04', '2022-11-02', '-'),
(31, 29, 41, '250000', '2022-08-04', '2022-11-02', '-'),
(32, 30, 42, '250000', '2022-08-04', '2022-11-02', '-'),
(33, 22, 43, '250000', '2022-08-04', '2022-11-02', '-'),
(34, 33, 44, '250000', '2022-08-04', '2022-11-02', '-'),
(35, 25, 45, '100000', '2022-08-04', '2022-11-02', '-'),
(36, 31, 46, '250000', '2022-08-04', '2022-11-02', '-'),
(37, 28, 47, '100000', '2022-08-04', '2022-11-02', '-'),
(38, 39, 48, '100000', '2022-08-04', '2022-11-02', '-'),
(39, 34, 49, '100000', '2022-08-04', '2022-11-02', '-'),
(40, 18, 50, '100000', '2022-08-04', '2022-11-02', '-'),
(41, 37, 51, '100000', '2022-08-04', '2022-11-02', '-'),
(42, 32, 52, '250000', '2022-08-04', '2022-11-02', '-'),
(43, 38, 53, '100000', '2022-08-04', '2022-11-02', '-'),
(44, 19, 54, '100000', '2022-08-04', '2022-11-02', '-'),
(45, 36, 55, '250000', '2022-08-04', '2022-11-02', '-'),
(46, 36, 56, '100000', '2022-05-04', '2022-08-02', '-'),
(47, 24, 57, '100000', '2022-05-05', '2022-08-03', '-'),
(48, 35, 58, '100000', '2022-05-06', '2022-08-04', '-'),
(49, 27, 59, '100000', '2022-05-07', '2022-08-05', '-'),
(50, 26, 60, '250000', '2022-05-08', '2022-08-06', '-'),
(51, 21, 61, '100000', '2022-05-09', '2022-08-07', '-'),
(52, 17, 62, '100000', '2022-08-08', '2022-11-06', '-'),
(53, 36, 63, '250000', '2022-08-04', '2022-11-02', '-'),
(54, 24, 64, '250000', '2022-08-04', '2022-11-02', '-'),
(55, 35, 65, '250000', '2022-08-04', '2022-11-02', '-'),
(56, 27, 66, '250000', '2022-08-04', '2022-11-02', '-'),
(57, 26, 67, '250000', '2022-08-04', '2022-11-02', '-'),
(58, 21, 68, '250000', '2022-08-04', '2022-11-02', '-'),
(59, 17, 69, '250000', '2022-08-04', '2022-11-02', '-'),
(60, 20, 70, '250000', '2022-08-01', '2022-10-30', '-'),
(61, 23, 71, '250000', '2022-07-31', '2022-10-29', '-'),
(62, 29, 72, '250000', '2022-04-04', '2022-07-03', '-'),
(63, 30, 73, '250000', '2022-04-04', '2022-07-03', '-'),
(64, 22, 74, '250000', '2022-04-04', '2022-07-03', '-'),
(65, 33, 75, '250000', '2022-04-04', '2022-07-03', '-'),
(66, 33, 76, '250000', '2022-04-04', '2022-07-03', '-'),
(67, 25, 77, '250000', '2022-04-04', '2022-07-03', '-'),
(68, 31, 78, '250000', '2022-03-04', '2022-06-02', '-'),
(69, 28, 79, '1000000', '2022-04-04', '2022-07-03', '-'),
(70, 39, 80, '9000000', '2022-04-04', '2022-07-03', '-'),
(71, 34, 81, '100000', '2022-04-04', '2022-07-03', '-'),
(72, 18, 82, '1000000', '2022-04-13', '2022-07-12', '-'),
(73, 37, 83, '100000', '2022-04-04', '2022-06-03', '-'),
(74, 37, 84, '100000', '2022-04-04', '2022-06-03', '-'),
(75, 32, 85, '1000000', '2022-04-04', '2022-07-03', '-'),
(76, 19, 86, '9000000', '2022-04-04', '2022-07-03', '-'),
(77, 38, 87, '250000', '2022-08-23', '2022-11-21', '-'),
(78, 28, 88, '250000', '2022-08-04', '2023-01-31', '-'),
(79, 41, 89, '250000', '2022-08-05', '2022-09-04', '-'),
(80, 42, 90, '1000000', '2022-08-05', '2022-11-03', '-'),
(81, 18, 91, '250000', '2022-08-18', '2022-08-05', '-'),
(82, 47, 92, '100000', '2022-08-10', '2022-09-09', '-'),
(83, 48, 93, '250000', '2022-08-06', '2022-11-04', '-'),
(84, 19, 94, '250000', '2022-08-07', '2022-08-27', '-'),
(85, 52, 95, '100000', '2022-08-14', '2022-11-12', '-'),
(86, 1, 96, '150000', '2022-05-14', '2022-08-12', '-'),
(87, 38, 97, '150000', '2022-08-16', '2022-09-05', '-');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transaksi`
--

CREATE TABLE `tbl_transaksi` (
  `id_transaksi` int(10) NOT NULL,
  `tgl_lunas` date NOT NULL,
  `jml_bayar` varchar(60) NOT NULL,
  `ket` varchar(20) DEFAULT NULL,
  `bunga` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_transaksi`
--

INSERT INTO `tbl_transaksi` (`id_transaksi`, `tgl_lunas`, `jml_bayar`, `ket`, `bunga`) VALUES
(8, '2022-08-04', '55000', 'Lunas', '5000'),
(9, '2022-08-10', '2750000', 'Lunas', '250000'),
(10, '2022-08-01', '5005000', 'Lunas', '455000'),
(12, '2022-08-01', '385000', 'Lunas', '35000'),
(22, '0000-00-00', '4550000', 'Belum Lunas', NULL),
(23, '2022-07-31', '4550000', 'Belum Lunas', NULL),
(24, '2022-08-04', '165000', 'Lunas', '15000'),
(25, '2022-08-04', '1100000', 'Lunas', '100000'),
(26, '2022-08-25', '1100000', 'Lunas', '100000'),
(27, '2022-08-04', '1100000', 'Lunas', '100000'),
(28, '2022-08-04', '110000', 'Lunas', '10000'),
(29, '2022-08-04', '275000', 'Lunas', '25000'),
(30, '2022-08-04', '275000', 'Lunas', '25000'),
(31, '2022-08-04', '275000', 'Lunas', '25000'),
(32, '2022-08-04', '275000', 'Lunas', '25000'),
(33, '2022-08-04', '275000', 'Lunas', '25000'),
(34, '2022-08-18', '9900000', 'Lunas', '900000'),
(35, '2022-10-03', '110000', 'Lunas', '10000'),
(36, '2022-08-04', '275000', 'Lunas', '25000'),
(37, '2022-08-04', '275000', 'Lunas', '25000'),
(38, '2022-08-04', '275000', 'Lunas', '25000'),
(39, '2022-08-04', '275000', 'Lunas', '25000'),
(40, '2022-08-04', '275000', 'Lunas', '25000'),
(41, '2022-08-04', '275000', 'Lunas', '25000'),
(42, '2022-08-04', '275000', 'Lunas', '25000'),
(43, '2022-08-04', '275000', 'Lunas', '25000'),
(44, '2022-08-04', '275000', 'Lunas', '25000'),
(45, '2022-08-04', '110000', 'Lunas', '10000'),
(46, '2022-08-04', '275000', 'Lunas', '25000'),
(47, '2022-08-04', '110000', 'Lunas', '10000'),
(48, '2022-08-04', '110000', 'Lunas', '10000'),
(49, '2022-08-04', '110000', 'Lunas', '10000'),
(50, '2022-08-04', '110000', 'Lunas', '10000'),
(51, '2022-08-04', '110000', 'Lunas', '10000'),
(52, '2022-08-04', '275000', 'Lunas', '25000'),
(53, '2022-08-04', '110000', 'Lunas', '10000'),
(54, '2022-08-04', '110000', 'Lunas', '10000'),
(55, '2022-08-04', '275000', 'Lunas', '25000'),
(56, '2022-05-04', '110000', 'Belum Lunas', '10000'),
(57, '2022-05-05', '110000', 'Belum Lunas', '10000'),
(58, '2022-05-06', '110000', 'Belum Lunas', '10000'),
(59, '2022-05-07', '110000', 'Belum Lunas', '10000'),
(60, '2022-05-08', '275000', 'Belum Lunas', '25000'),
(61, '2022-05-09', '110000', 'Belum Lunas', '10000'),
(62, '2022-08-14', '110000', 'Lunas', '10000'),
(63, '2022-08-04', '275000', 'Belum Lunas', '25000'),
(64, '2022-08-04', '275000', 'Belum Lunas', '25000'),
(65, '2022-08-04', '275000', 'Belum Lunas', '25000'),
(66, '2022-08-04', '275000', 'Belum Lunas', '25000'),
(67, '2022-08-04', '275000', 'Belum Lunas', '25000'),
(68, '2022-08-04', '275000', 'Belum Lunas', '25000'),
(69, '2022-08-04', '275000', 'Belum Lunas', '25000'),
(70, '2022-08-01', '275000', 'Belum Lunas', '25000'),
(71, '2022-07-31', '275000', 'Belum Lunas', '25000'),
(72, '2022-04-04', '275000', 'Belum Lunas', '25000'),
(73, '2022-04-04', '275000', 'Belum Lunas', '25000'),
(74, '2022-04-04', '275000', 'Belum Lunas', '25000'),
(75, '2022-04-04', '275000', 'Belum Lunas', '25000'),
(76, '2022-04-04', '275000', 'Belum Lunas', '25000'),
(77, '2022-04-04', '275000', 'Belum Lunas', '25000'),
(78, '2022-03-04', '275000', 'Belum Lunas', '25000'),
(79, '2022-04-04', '1100000', 'Belum Lunas', '100000'),
(80, '2022-04-04', '9900000', 'Belum Lunas', '900000'),
(81, '2022-04-04', '110000', 'Belum Lunas', '10000'),
(82, '2022-04-13', '1100000', 'Belum Lunas', '100000'),
(83, '2022-04-04', '110000', 'Belum Lunas', '10000'),
(84, '2022-08-07', '110000', 'Lunas', '10000'),
(85, '2022-08-07', '1100000', 'Lunas', '100000'),
(86, '2022-08-07', '9900000', 'Lunas', '900000'),
(87, '2022-08-23', '275000', 'Belum Lunas', '25000'),
(88, '2022-08-04', '275000', 'Belum Lunas', '25000'),
(89, '2022-08-05', '275000', 'Belum Lunas', '25000'),
(90, '2022-08-05', '1100000', 'Belum Lunas', '100000'),
(91, '2022-08-18', '275000', 'Belum Lunas', '25000'),
(92, '2022-08-05', '110000', 'Lunas', '10000'),
(93, '2022-08-13', '275000', 'Lunas', '25000'),
(94, '2022-08-07', '275000', 'Belum Lunas', '25000'),
(95, '2022-08-14', '110000', 'Belum Lunas', '10000'),
(96, '2022-05-14', '165000', 'Belum Lunas', '15000'),
(97, '2022-08-16', '165000', 'Belum Lunas', '15000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transaksi_unggul`
--

CREATE TABLE `tbl_transaksi_unggul` (
  `id_transaksi` int(11) NOT NULL,
  `tgl_lunas` date NOT NULL,
  `jml_bayar` varchar(60) NOT NULL,
  `ket` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_transaksi_unggul`
--

INSERT INTO `tbl_transaksi_unggul` (`id_transaksi`, `tgl_lunas`, `jml_bayar`, `ket`) VALUES
(2, '2022-08-01', '4550000', 'Lunas'),
(3, '2022-07-24', '5550000', 'Belum Lunas'),
(4, '2022-05-02', '250000', 'Belum Lunas'),
(5, '2022-05-02', '250000', 'Belum Lunas'),
(6, '2022-05-02', '250000', 'Belum Lunas'),
(7, '2022-01-03', '250000', 'Belum Lunas'),
(8, '2022-08-04', '250000', 'Belum Lunas'),
(9, '2022-04-04', '100000', 'Belum Lunas'),
(10, '2022-08-04', '250000', 'Belum Lunas'),
(11, '2022-08-04', '250000', 'Belum Lunas'),
(12, '2022-08-04', '250000', 'Belum Lunas'),
(13, '2022-08-04', '250000', 'Belum Lunas'),
(14, '2022-08-04', '250000', 'Belum Lunas'),
(15, '2022-08-04', '250000', 'Belum Lunas'),
(16, '2022-08-04', '250000', 'Belum Lunas'),
(17, '2022-08-04', '250000', 'Belum Lunas'),
(18, '2022-08-04', '250000', 'Belum Lunas'),
(19, '2022-08-04', '250000', 'Belum Lunas'),
(20, '2022-08-04', '250000', 'Belum Lunas'),
(21, '2022-08-04', '250000', 'Belum Lunas'),
(22, '2022-08-04', '250000', 'Belum Lunas'),
(23, '2022-08-04', '250000', 'Belum Lunas'),
(24, '2022-08-04', '250000', 'Belum Lunas'),
(25, '2022-08-04', '250000', 'Belum Lunas'),
(26, '2022-08-04', '250000', 'Belum Lunas'),
(27, '2022-08-04', '250000', 'Lunas'),
(28, '2022-08-04', '250000', 'Belum Lunas'),
(29, '2022-08-04', '250000', 'Belum Lunas'),
(30, '2022-08-04', '250000', 'Lunas'),
(31, '2022-08-04', '250000', 'Belum Lunas'),
(32, '2022-08-04', '250000', 'Belum Lunas'),
(33, '2022-08-04', '250000', 'Lunas'),
(34, '2022-08-04', '250000', 'Belum Lunas'),
(35, '2022-08-05', '1000000', 'Lunas'),
(36, '2022-08-01', '1000000', 'Belum Lunas'),
(37, '2022-12-31', '100000', 'Lunas'),
(38, '2022-08-16', '100000', 'Belum Lunas');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_unggulan`
--

CREATE TABLE `tbl_unggulan` (
  `id_unggulan` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_transaksi` int(11) NOT NULL,
  `jml_pinjaman` varchar(60) NOT NULL,
  `tgl_pinjaman` date NOT NULL,
  `tgl_tenggat` date NOT NULL,
  `jaminan` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_unggulan`
--

INSERT INTO `tbl_unggulan` (`id_unggulan`, `id_user`, `id_transaksi`, `jml_pinjaman`, `tgl_pinjaman`, `tgl_tenggat`, `jaminan`) VALUES
(12, 21, 2, '4550000', '2022-07-31', '2023-01-27', 'BPKB'),
(13, 19, 3, '5550000', '2022-07-24', '2023-01-20', 'STNK'),
(14, 36, 4, '250000', '2022-05-02', '2022-10-29', '-'),
(15, 24, 5, '250000', '2022-05-02', '2022-10-29', '-'),
(16, 35, 6, '250000', '2022-05-02', '2022-10-29', '-'),
(17, 32, 7, '250000', '2022-01-03', '2022-07-02', '-'),
(18, 27, 8, '250000', '2022-08-04', '2023-01-31', '-'),
(19, 32, 9, '100000', '2022-04-04', '2022-05-04', '-'),
(20, 36, 10, '250000', '2022-08-04', '2023-01-31', '-'),
(21, 24, 11, '250000', '2022-08-04', '2023-01-31', '-'),
(22, 24, 12, '250000', '2022-08-04', '2023-01-31', '-'),
(23, 35, 13, '250000', '2022-08-04', '2023-01-31', '-'),
(24, 27, 14, '250000', '2022-08-04', '2023-01-31', '-'),
(25, 26, 15, '250000', '2022-08-04', '2023-01-31', '-'),
(26, 21, 16, '250000', '2022-08-04', '2023-01-31', '-'),
(27, 17, 17, '250000', '2022-08-04', '2023-01-31', '-'),
(28, 20, 18, '250000', '2022-08-04', '2023-01-31', '-'),
(29, 23, 19, '250000', '2022-08-04', '2023-01-31', '-'),
(30, 29, 20, '250000', '2022-08-04', '2023-01-31', '-'),
(31, 30, 21, '250000', '2022-08-04', '2023-01-31', '-'),
(32, 22, 22, '250000', '2022-08-04', '2023-01-31', '-'),
(33, 33, 23, '250000', '2022-08-04', '2023-01-31', '-'),
(34, 25, 24, '250000', '2022-08-04', '2023-01-31', '-'),
(35, 31, 25, '250000', '2022-08-04', '2023-01-31', '-'),
(36, 28, 26, '250000', '2022-08-04', '2023-01-31', '-'),
(37, 28, 27, '250000', '2022-08-04', '2023-01-31', '-'),
(38, 39, 28, '250000', '2022-08-04', '2023-01-31', '-'),
(39, 34, 29, '250000', '2022-08-04', '2023-01-31', '-'),
(40, 18, 30, '250000', '2022-08-04', '2023-01-31', '-'),
(41, 37, 31, '250000', '2022-08-04', '2023-01-31', '-'),
(42, 32, 32, '250000', '2022-08-04', '2023-01-31', '-'),
(43, 19, 33, '250000', '2022-08-04', '2023-01-31', '-'),
(44, 38, 34, '250000', '2022-08-04', '2023-01-31', '-'),
(45, 47, 35, '1000000', '2022-08-05', '2022-11-03', '-'),
(46, 48, 36, '1000000', '2022-08-01', '2022-10-30', '-'),
(47, 52, 37, '100000', '2022-08-14', '2022-12-12', '-'),
(48, 54, 38, '100000', '2022-08-16', '2022-12-14', '-');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(20) NOT NULL,
  `nama_pengguna` varchar(50) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `ttl` varchar(55) DEFAULT NULL,
  `no_ktp` varchar(60) DEFAULT NULL,
  `no_hp` varchar(55) DEFAULT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(125) NOT NULL,
  `user` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `nama_pengguna`, `alamat`, `ttl`, `no_ktp`, `no_hp`, `email`, `password`, `user`) VALUES
(1, 'Sahabudin-Admin', '-', '-', '-', '', 'admin@gmail.com', '$2y$10$.AjDaCn2HsLOU3BWl0IliuFNbrx/yyiinhBmKqJrbisqT7lOJHtjy', 'admin'),
(17, 'Jumran', 'Endut Tojang', 'Endut Tojang, 31-12-1973', '5270012930030001', '0878883333222', 'jumran@gmail.com', '$2y$10$hsFTXrc2hq1QvHtDC.JwOu1G6gx93deTN7qhhhBrq2IWRGVF0WEXG', 'user'),
(18, 'Sahurim', 'Endut Tojang', 'Endut Tojang, 31-12-1970', '5271011705970001', '0878883333222', 'sahurim@gmail.com', '$2y$10$3lPCZkKw4nQDrrQqDQ/CUegClrXF75TQEpC1RpOw2DdFDVvt6gcMu', 'user'),
(19, 'Supardi', 'Endut Tojang', 'Endut Tojang, 31-12-1975', '3321116502910000', '0878883333222', 'supardi@gmail.com', '$2y$10$4OgOWxkPP4mhPdmJ0buuvevuS7XInWqC94//lp0RzBqmJ6DpoPOxe', 'user'),
(20, 'Kamarudin', 'Endut Tojang', 'Endut Tojang, 31-12-1970', '3321060902150009', '0878883333222', 'kamarudn@gmail.com', '$2y$10$I7Cpnl5BAz1PmQYON4pa8ejGoGQHFWYc7LMiOwpxm7F3MJ5tU7lDO', 'user'),
(21, 'Jawini', 'Endut Tojang', 'Endut Tojang, 31-12-1976', '3321050312850000', '0878883333222', 'jawini@gmail.com', '$2y$10$I8jKtEyBFrB9MLpazd8ULu.HvBnCSxAw.zNdBd2lu8bbNic5B56ke', 'user'),
(22, 'Mat', 'Endut Tojang', 'Endut Tojang, 31-12-1993', '3321112510070018', '083113239001', 'mat@gmail.com', '$2y$10$NfABX9xADROMvj2vYBl5Deb1bIF8QClAldDiBITEWc3ombiJ0kXh.', 'user'),
(23, 'Lacih', 'Endut Tojang', 'Endut Tojang, 31-12-1988', '402020607084312', '081917992239', 'lacih@gmail.com', '$2y$10$9gvDH/4jAXGJUow7i1Ab8OFFBEWchB3pIL0tnmG4GnqiDVg1f7TEe', 'user'),
(24, 'Amaq Rusnah', 'Endut Tojang', 'Endut Tojang, 31-12-1960', '5271011505970001', '085158817597', 'amaqrusnah@gmail.com', '$2y$10$esHrR7OS9iMJvKo1rL6b7Of7sGmH/EgpcugNvHNm.a9Kcx5YSJM46', 'user'),
(25, 'Munawar', 'Endut Tojang', 'Endut Tojang, 31-12-1980', '5202122309990009', '0878883333222', 'munnawar@gmail.com', '$2y$10$oQFD5NIT.byYnMhpQNR25uAAPHAz83Mj5Nyhc7VHgaEHiPs/CbPxW', 'user'),
(26, 'Inaq Sahman', 'Endut Tojang', 'Endut Tojang, 31-12-1963', '5202122309990005', '0878883333222', 'inaqsahman@gmail.com', '$2y$10$U1Cp73dEdnlRUqrq.0LJAukXTeAGbnXAYo5gBRvWRWHXOmqMnWzR2', 'user'),
(27, 'Basirun', 'Endut Tojang', 'Endut Tojang, 31-12-1970', '5202121706988431', '0878883333222', 'basirun@gmail.com', '$2y$10$jPmanjb9ApAO28s3K7i8TOMGGc2bz4fLq1.AmtfVK6Pck7yRs0EqG', 'user'),
(28, 'Rabbul Azhar', 'Endut Tojang', 'Endut Tojang, 31-12-1989', '5202122309990003', '0878883333222', 'rabbulazhar@gmail.com', '$2y$10$oDVuS.k2Uhk6ZvS/TLQp6eFDM9gxffKLCT5mnV3ftewGE.9WVIQiS', 'user'),
(29, 'Mahdi', 'Endut Tojang', 'Endut Tojang, 31-12-1970', '5202122309990009', '0878883333222', 'mahdi@gmail.com', '$2y$10$XfoQrxTyGWapL9NCtxwiVOyu.kUK2kdFwxrkMuVOoqY3knmdZE0Dq', 'user'),
(30, 'Mahidin', 'Endut Tojang', 'Endut Tojang, 31-12-1979', '5202122309990002', '0878883333222', 'mahidin@gmail.com', '$2y$10$TvyUGysBiYNze2etWAxp/eQ5D5AnawuRP//58y20kjszO9iWpwVRG', 'user'),
(31, 'Pauzan', 'Endut Tojang', 'Endut Tojang, 23-06-1993', '5202122309990003', '0878883333222', 'pauzan@gmail.com', '$2y$10$Hu/INKtRNA1EEVMIPAfF2uc52l6csJ2szPeoa4SvIUFEX8StWIfUO', 'user'),
(32, 'Sulhan', 'Endut Tojang', 'Endut Tojang, 31-12-1995', '5202122309990005', '0878883333222', 'sulhan@gmail.com', '$2y$10$ueM9oRl05ut.RfHwcXHlzO1/VHAnTEY0y7vuWWbEiEaz9uaqZ3Czu', 'user'),
(33, 'Muhardi', 'Endut Tojang', 'Endut Tojang, 31-12-1978', '5202122309990005', '0878883333222', 'muhardi@gmail.com', '$2y$10$OE9QXMByw3thXXB2LyUH2e/CfMNbexj8vgVohBRPj4pUZ0CyN.4KG', 'user'),
(34, 'Sahnim', 'Endut Tojang', 'Endut Tojang, 31-12-1982', '5202121706988431', '0878883333222', 'sahnim@gmail.com', '$2y$10$z5INoN9.5gO9sJ9zMqw8reqpjnducAPIsX9pxL4iH/W9sk6Mosvl2', 'user'),
(35, 'Asmail', 'Endut Tojang', 'Endut Tojang, 31-12-1989', '5202121706988431', '0878883333222', 'asmail@gmail.com', '$2y$10$pyD2hUswlzgQb3dAmAzWJ.blFjEjFdod4CVIzVZmoxNxeXWvUocES', 'user'),
(36, 'Amaq Rohaini', 'Endut Tojang', 'Endut Tojang, 31-12-1969', '5202122309990002', '0878883333222', 'amaqrohaini@gmail.com', '$2y$10$GSMz5T73zNtb0o2BtYgsv.lZM1LG3yetPXGyPECXTBUSdGXMBSyVK', 'user'),
(37, 'Suarni', 'Endut Tojang', 'Endut Tojang, 31-12-1980', '5202122309990002', '0878883333222', 'suarni@gmail.com', '$2y$10$/aLh/IbLv1Mr4Bi/IqZkmu.6IcczVwcwpKranVWN0boNw4BYEOea.', 'user'),
(38, 'Sutarman', 'Endut Tojang', 'Endut Tojang, 31-12-1977', '5202122309990001', '0878883333222', 'sutarman@gmail.com', '$2y$10$lIGqLOM3PvalhwdQvnWrkOl7iZdlMhNjVYXLI.XadHkBRZ.6w1n.a', 'user'),
(39, 'Sahman', 'Endut Tojang', 'Endut Tojang, 31-12-1970', '5202122309990005', '0878883333222', 'sahman@gmail.com', '$2y$10$0iax5yPWzNzicZ4zyJBg0.3HK5ar8vPcMFRZcTZ8bbwyckVC6IT72', 'user'),
(50, 'Sahida', 'Endut Tojang', 'Endut Tojang, 31-12-1989', '5202122309990004', '0878883333222', 'sahida@gmail.com', '$2y$10$Au1gnoKwNbTKrJyTkwtRN./Do..FTIIOHv6XrkCP/uRp1xKiRUfJS', 'user'),
(52, 'Sakrah', 'Endut Tojang', 'Endut Tojang, 31-12-1970', '5202122309980025', '0878883333222', 'sakrah@gmail.com', '$2y$10$oQe9RZpMj9Gp6qB8jqkwyOCEzBsDYEDofm4h.vTR.0okMBXI5TDfq', 'user'),
(54, 'buk zaeniah', 'Mataram', 'mataran, 22 agustus 1980', '5202121706988433', '089754522890', 'bukzaeniah@gmail.com', '$2y$10$GGX995kR0JB78h0T56DiFO0OkG5m9UNFoe/yWswH1oZjXUHatnddu', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_pinjaman`
--
ALTER TABLE `tbl_pinjaman`
  ADD PRIMARY KEY (`id_pinjaman`);

--
-- Indexes for table `tbl_transaksi`
--
ALTER TABLE `tbl_transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `tbl_transaksi_unggul`
--
ALTER TABLE `tbl_transaksi_unggul`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `tbl_unggulan`
--
ALTER TABLE `tbl_unggulan`
  ADD PRIMARY KEY (`id_unggulan`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_pinjaman`
--
ALTER TABLE `tbl_pinjaman`
  MODIFY `id_pinjaman` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `tbl_transaksi`
--
ALTER TABLE `tbl_transaksi`
  MODIFY `id_transaksi` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `tbl_transaksi_unggul`
--
ALTER TABLE `tbl_transaksi_unggul`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tbl_unggulan`
--
ALTER TABLE `tbl_unggulan`
  MODIFY `id_unggulan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
